package com.zetcode;

public enum GameState {
    START_MENU, IN_GAME, GAME_OVER, PAUSE_GAME
}

