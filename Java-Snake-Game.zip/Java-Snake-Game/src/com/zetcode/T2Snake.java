package com.zetcode;
public class T2Snake {
    private Board board;
    public T2Snake(Board board) {
        this.board = board;
    }

// ... Add other necessary properties and methods for T2Snake ...

    public void initGame() {
        int currentDelay = board.getDelay();
        int newDelay = currentDelay - 50;
        board.setDelay(newDelay);
    }
}
