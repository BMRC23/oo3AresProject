package com.zetcode;

public class T3Snake {
    private Board board;

    public T3Snake(Board board) {
        this.board = board;
    }

// ... Add other necessary properties and methods for T3Snake ...

    public void initGame() {
        int currentDelay = board.getDelay();
        int newDelay = currentDelay - 50;
        board.setDelay(newDelay);
    }
}

